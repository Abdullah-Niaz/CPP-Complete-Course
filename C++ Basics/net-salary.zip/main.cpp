/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    // write a program to set the net salary 
    float basic;
    float percentAllow;
    float percentDeduct;
    float netSalary;
    cout<<"Enter the Bacic Salary ";
    cin>>basic;
    cout<<"Enter the Allowance ";
    cin>>percentAllow;
    cout<<"Enter the Deduction ";
    cin>>percentDeduct;
    netSalary = basic + basic * percentAllow/100 - basic * percentDeduct/100;
    cout<<"Your Net Salary is "<<netSalary<<endl;
    return 0;
}